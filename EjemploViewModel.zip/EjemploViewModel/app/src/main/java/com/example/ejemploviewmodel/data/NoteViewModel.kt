package com.example.ejemploviewmodel.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class NoteViewModel(application: Application) : AndroidViewModel(application){

}